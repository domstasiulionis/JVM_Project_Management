fun main(args: Array<String>) {
    val home = Home()
    home.setBounds(1500, 1500, 1200, 900)
    home.setLocationRelativeTo(null)
    home.isResizable = false
    home.isVisible = true
}